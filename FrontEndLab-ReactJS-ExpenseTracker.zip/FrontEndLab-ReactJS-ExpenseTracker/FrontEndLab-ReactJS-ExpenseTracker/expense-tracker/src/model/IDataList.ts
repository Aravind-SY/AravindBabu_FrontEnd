export default interface IDataList {
    id: number;
    product: string,
    price: number,
    payeeName: string,
    setDate: string
}